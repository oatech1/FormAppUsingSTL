package com.oatech.model;

import java.util.List;

import javax.persistence.CollectionTable;
import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OrderColumn;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;
@Entity
@Table(name ="emp_tab")
//@XmlRootElement
public class Employee {
	@Id
	@Column(name ="emp_id")
	@GeneratedValue
	private Integer empId;
	@Column(name ="emp_name")
	private String empName;
	@Column(name ="emp_pwd")
	private String empPwd;
	@Column(name ="emp_gen")
	private String empGender;
	@Column(name ="emp_addr")
	private String empAddr;
	@Column(name ="emp_country")
	private String empCountry;
	/*@ElementCollection
	@CollectionTable(name ="emplangtab", joinColumns = @JoinColumn(name ="emp_id"))
	@OrderColumn(name ="pos")
	@Column(name ="lang")
	private List<String> empLang;*/
	
	
	public Employee() {
		super();
	}


	public Employee(Integer empId) {
		super();
		this.empId = empId;
	}


	/**
	 * @return the empId
	 */
	public Integer getEmpId() {
		return empId;
	}


	/**
	 * @param empId the empId to set
	 */
	public void setEmpId(Integer empId) {
		this.empId = empId;
	}


	/**
	 * @return the empName
	 */
	public String getEmpName() {
		return empName;
	}


	/**
	 * @param empName the empName to set
	 */
	public void setEmpName(String empName) {
		this.empName = empName;
	}


	/**
	 * @return the empPwd
	 */
	public String getEmpPwd() {
		return empPwd;
	}


	/**
	 * @param empPwd the empPwd to set
	 */
	public void setEmpPwd(String empPwd) {
		this.empPwd = empPwd;
	}


	/**
	 * @return the empGender
	 */
	public String getEmpGender() {
		return empGender;
	}


	/**
	 * @param empGender the empGender to set
	 */
	public void setEmpGender(String empGender) {
		this.empGender = empGender;
	}


	/**
	 * @return the empAddr
	 */
	public String getEmpAddr() {
		return empAddr;
	}


	/**
	 * @param empAddr the empAddr to set
	 */
	public void setEmpAddr(String empAddr) {
		this.empAddr = empAddr;
	}


	/**
	 * @return the empCountry
	 */
	public String getEmpCountry() {
		return empCountry;
	}


	/**
	 * @param empCountry the empCountry to set
	 */
	public void setEmpCountry(String empCountry) {
		this.empCountry = empCountry;
	}

}
