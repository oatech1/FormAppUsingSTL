package com.oatech.validation;




import java.util.regex.Pattern;

import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import com.oatech.model.Employee;

@Component
public class EmployeeValidation implements Validator{

	@Override
	public boolean supports(Class<?> clazz) {
		return Employee.class.equals(clazz);
	}

	@Override
	public void validate(Object target, Errors errors) {
		Employee emp =(Employee) target;//downcasting Object (employee)
		if(!Pattern.matches("[A-Za-z]{4,9}", emp.getEmpName())) {
			errors.rejectValue("empName", null, "Please put A-Z a-z min 4 max 9");
		}if (!Pattern.matches("[A-Za-z0-9]{4,8}", emp.getEmpPwd())) {
			errors.rejectValue("empPwd", null, "Please Put A-Z a-z 0-9 min 4 max9");
		}if (!StringUtils.hasText(emp.getEmpGender())) {
			errors.rejectValue("empGender", null, "Please Select one Gender");
		}if (!Pattern.matches("[A-Za-z0-9]{10,20}", emp.getEmpAddr())) {
			errors.rejectValue("empAddr", null, "Address min 10 latter max 250");
		}if(!StringUtils.hasText(emp.getEmpCountry())) {
			errors.rejectValue("empCountry", null, "Please Select atleast one Country");
		}
		/*if(emp.getEmpLang()==null|| emp.getEmpLang().isEmpty()) {
			errors.rejectValue("empLang", null, "Please Select at least one language");
		}*/
	}

}
