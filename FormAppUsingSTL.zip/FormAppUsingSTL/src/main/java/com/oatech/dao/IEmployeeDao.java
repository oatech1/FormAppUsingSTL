package com.oatech.dao;

import java.util.List;

import com.oatech.model.Employee;

public interface IEmployeeDao {
	public Integer saveEmployee(Employee emp);
	
	public List<Employee> getAllEmployee();
	
	public Employee getOneRecord(Integer id);
	
	public void updateEmployee(Employee emp);
	
	public void deleteEmployee(Integer id);
}
